#ifndef hpp_CPP_DynamicObject_CPP_hpp
#define hpp_CPP_DynamicObject_CPP_hpp

// We need Variant too
#include "../Variant/Variant.hpp"
// We need Hash map
#include "../Hash/HashTable.hpp"



namespace Type
{
    

    /** A dynamic object is an object those attributes and methods are dynamically registered
        This is used for scripted languages mainly, and JSON parser from other languages
        
        Example usage code
        @code
            DynObj obj;
            // Attribute setting
            obj.setMember("foo", 3);
            obj.setMember("bar", String("Hello"));
            obj.setMember("baz", String("world"));
            
            // Static method
            int sum(int & result, int val) { result += val; return result; }
            // You need to write a wrapper code to call it
            Var sum_wrap(const DynObj::Args & args) { int ** result = (int**)args.args[0].like((void*)0); return sum(*result, args.args[1].like((int*)0)); }
            obj.setMember("sum", &sum_wrap); // Taking the address here is very important
            
            // Member method
            Var dumpMe(const DynObj::Args & args) 
            { 
                DynObj * obj = (DynObj*)args.thisObj; 
                const DynObj::EntryIterT & iter = obj->getEntryIterator();
                while (iter.isValid()) { Logger::log(Logger::Dump, "%s: %s", (const char*)iter.getKey(), (const char*) (*iter)->like((String*)0)); ++iter; }
            }
            obj.setMember("dump", &dumpMe);
            
            // Another member method
            Var hello(const DynObj::Args & args)
            {
                DynObj * obj = (DynObj*)args.thisObj;
                String end = obj->getMember("bar").like(&end) + obj->getMember("baz").like(&end) + args.args[0].like(&end);
                obj->setMember("qux", end);
                return end;
            }
            obj.setMember("hello", &hello);
            
            // Invoke a method on the dynamic object
            obj.invoke("dump");
            // Invoke a method on the dynamic object
            String ret = obj.invoke("hello", " Bob").like((String*)0); 
            Assert(ret == "Helloworld Bob");
        @endcode 
        
        You can also store a C++ instance of a class like this:
        @code
            struct TestObj
            {
                int value;
                void sum(int operand) { value += operand; }
                TestObj() : value(0) {}
            };
     
            TestObj * small = new TestObj;
            DynObj obj;
            obj.setInternalObject(small); // Own the instance (use ref not to own the instance)
            obj.setMember("sum", WrapMemberFunc(TestObj, int, &TestObj::sum)); // WrapMemberFunc is a macro that avoid writing a wrapper
        @endcode
        
        If you need to write code with DynObj attribute access in method, you'll be interested by 
        the assertArgsCount, assertTypeCast, and checkFuncCall functions that perform error handling for you.
        */
    class DynObj
    {
        // Type definition and enumeration
    public:
        /** The function argument list we are using */
        typedef FuncArgs Args;
        /** The string class we are using */
        typedef Strings::FastString String;
        /** The Hash table we are using */
        typedef Container::HashTable<Var, String, Container::HashKey<String>, Container::DeletionWithDelete<Var>, false, true> MemberHash;
        /** The deleter function to use if storing an internal object in this object */
        typedef void (*DeleterFunc)(void *);
        
        /** The useful function that's used for deleting an internal object */
        template <typename T>
        static void makeDeleter(void * ptr) { delete (T*)ptr; }
        /** Entry iterator interface.
            The only way to get it is to write "const EntryIterator & iter = obj.getEntryIterator();" */
        class EntryIterT
        {
            MemberHash::IterT iter;
        public:
            const EntryIterT & operator++() const { ++iter; return *this; }
            bool isValid() const { return iter.isValid(); }
            const String & getKey() const { return *iter.getKey(); }
            const Var* operator *() const { return *iter; }
            bool operator == (const EntryIterT & it) const { return iter == it.iter; }
            bool operator != (const EntryIterT & it) const { return iter != it.iter; }
            
        public:
            EntryIterT(const MemberHash::IterT & iter) : iter(iter) {}
            EntryIterT(const EntryIterT & other) : iter(other.iter) {}
        };
        /** Attribute iterator interface.
            The only way to get it is to write "const AttributeIterator & iter = obj.getAttributeIterator();" */
        class AttrIterT
        {
            MemberHash::IterT iter;
        public:
            const AttrIterT & operator++() const { ++iter; while (iter.isValid() && isMethod(*iter)) ++iter; return *this; }
            bool isValid() const { return iter.isValid(); }
            const String & getKey() const { return *iter.getKey(); }
//            Var * operator *() { return *iter; }
            const Var* operator *() const { return *iter; }
            bool operator == (const AttrIterT & it) const { return iter == it.iter; }
            bool operator != (const AttrIterT & it) const { return iter != it.iter; }
            
        public:
            AttrIterT(const MemberHash::IterT & iter) : iter(iter) { while (iter.isValid() && isMethod(*iter)) ++iter; }
            AttrIterT(const AttrIterT & other) : iter(other.iter) {}
        };
        
        /** The type of error that's thrown by ThrowOnError's callback */
        struct InvokeError { ErrorCallback::ErrorType type; String message; InvokeError(const ErrorCallback::ErrorType type, const String & msg) : type(type), message(msg) {} };
        
        /** An implementation of the ErrorCallback interface that throw upon any error */
        struct ThrowOnError : public ErrorCallback
        { virtual Var & errorDetected(Var & ret, const ErrorCallback::ErrorType type, const String & msg) const { throw InvokeError(type, msg); return ret; } };
        
        // Members
    private:
        /** The hash map for members */
        MemberHash hash;
        /** The error callback if any */
        ErrorCallback * errorCb;
        /** Owned internal ? */
        DeleterFunc deleter;
    
        // Helpers
    private:
        /** Get the method pointer */
        inline NamedFunc getMethod(const String & name) const { Var method = getMember(name); NamedFunc func = 0; if (method.isEmpty() || !method.extractTo(func)) return 0; return func; }
        /** Check if the given variant is a method */
        static inline bool isMethod(const Var * var) { return var && var->isExactly((NamedFunc*)0); }
        /** Delete the internal object if it exists */
        inline void deleteInternalObj()
        {
            if (deleter)
            {
                void * ptr = getMember("$this").like((void**)0);
                if (ptr) deleter(ptr);
                deleter = 0;
            }
        }
    
        // Introspection interface
    public:
        /** Check if the object owns a given method (either attribute or method) */
        inline bool hasMethod(const String & memberName) const { Var * var = hash.getValue(memberName); return isMethod(var); }
        /** Check if the object owns a given attribute */
        inline bool hasAttribute(const String & attrName) const { Var * var = hash.getValue(attrName); return var && !isMethod(var); }
        /** Check if the object has a member with the given name */
        inline bool hasMember(const String & name) const { return hash.getValue(name) != 0; }
        /** Get an attribute or method with the given name
            @param name     The attribute name
            @return empty Var if not found, the attribute if found. */
        inline Var getMember(const String & name) const { Var * var = hash.getValue(name); if (!var) return Var(); return *var; }
        
        /** Set a member.
            This replace an existing member of the same name.
            @sa WrapFunc macro
            @param name    The member name
            @param value   The member's value (can be a attribute, or a NamedFunc for a method) */
        inline void setMember(const String & name, const Var & value) { if (!name) return; if (value.isEmpty()) hash.removeValue(name); else hash.storeValue(name, new Var(value), true); }
        /** Get the number of members */
        inline size_t getMembersCount() const { return hash.getSize(); }
        /** Get the number of attributes */
        inline size_t getAttributesCount() const { size_t c = 0; for (MemberHash::IterT iter = hash.getFirstIterator(); iter.isValid(); ++iter) { c += !isMethod(*iter) ? 1 : 0; }  return c; }
        /** Iterate all members entries.
            You can not build this object directly, you typically have to write code like this:
            @code
            const EntryIterT & iter = obj.getEntryIterator(); // The compiler will extend the life of the temporary until iter goes out of scope.
            while (iter.isValid()) dump(*iter);
            @endcode */
        inline EntryIterT getEntryIterator() const { return EntryIterT(hash.getFirstIterator()); }
        /** Iterate only the attributes entries
            You can not build this object directly, you typically have to write code like this:
            @code
            const AttrIterT & iter = obj.getAttributeIterator(); // The compiler will extend the life of the temporary until iter goes out of scope.
            while (iter.isValid()) dump(*iter);
            @endcode */
        inline AttrIterT getAttributeIterator() const { return AttrIterT(hash.getFirstIterator()); }
        
        
        /** Invoke a method with the given identifier (without argument).
            @param name    The method name
            @return The method returned value */
        inline Var invoke(const String & name)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            return (*func)(Args(this, 0, 0, *errorCb));
        }
        /** Invoke a method with the given identifier (unary).
            @param name    The method name
            @param arg     The argument to use
            @return The method returned value */
        Var invoke(const String & name, const Var & arg)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            return (*func)(Args(this, &arg, 1, *errorCb));
        }
        /** Invoke a method with the given identifier (binary).
            @param name    The method name
            @param arg1    The argument to use
            @param arg2    The argument to use
            @return The method returned value */
        Var invoke(const String & name, const Var & arg1, const Var & arg2)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            const Var args[] = { arg1, arg2 };
            return (*func)(Args(this, args, 2, *errorCb));
        }
        /** Invoke a method with the given identifier (ternary).
            @param name    The method name
            @param arg1    The argument to use
            @param arg2    The argument to use
            @param arg3    The argument to use
            @return The method returned value */
        Var invoke(const String & name, const Var & arg1, const Var & arg2, const Var & arg3)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            const Var args[] = { arg1, arg2, arg3 };
            return (*func)(Args(this, args, 3, *errorCb));
        }
        /** Invoke a method with the given identifier (4-ary).
            @param name    The method name
            @param arg1    The argument to use
            @param arg2    The argument to use
            @param arg3    The argument to use
            @param arg4    The argument to use
            @return The method returned value */
        Var invoke(const String & name, const Var & arg1, const Var & arg2, const Var & arg3, const Var & arg4)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            const Var args[] = { arg1, arg2, arg3, arg4 };
            return (*func)(Args(this, args, 4, *errorCb));
        }
        /** Invoke a method with the given identifier (5-ary).
            @param name    The method name
            @param arg1    The argument to use
            @param arg2    The argument to use
            @param arg3    The argument to use
            @param arg4    The argument to use
            @param arg5    The argument to use
            @return The method returned value */
        Var invoke(const String & name, const Var & arg1, const Var & arg2, const Var & arg3, const Var & arg4, const Var & arg5)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            const Var args[] = { arg1, arg2, arg3, arg4, arg5 };
            return (*func)(Args(this, args, 5, *errorCb));
        }
        
        /** Invoke a method with any number of argument */
        Var invoke(const String & name, const Var * args, const size_t count)
        {
            NamedFunc func = getMethod(name); if (!func) return Var();
            return (*func)(Args(this, args, count, *errorCb));
        }
        
        /** Set the default error callback to use (default is no handling for errors).
            @param callback  The reference to a ErrorCallback child that's not own and must live after this object. 
                             If unsure, use Type::defaultHandling or Type::defaultThrow */
        void setErrorCallback(ErrorCallback & callback) { errorCb = &callback; }
        
        /** Set internal object. 
            This can be used to link a dynamic object with an instance of any class.
            @param obj    A reference to the object to store in the dynamic object. It's accessible via "$this" name. 
                          The object must exist during the complete lifetime of the dynamic object. */
        template <class T>
        inline void setInternalObject(T & obj) { deleteInternalObj(); setMember("$this", (void *)&obj); deleter = 0; }
        /** Set internal object. 
            This can be used to link a dynamic object with an instance of any class.
            @param obj    A pointer to the object to store in the dynamic object. It's accessible via "$this" name.
                          The object is owned by the dynamic object. */
        template <class T>
        inline void setInternalObject(T * obj) { deleteInternalObj(); setMember("$this", (void *)obj); deleter = &makeDeleter<T>; }
        
        
        
        DynObj() : errorCb(&defaultHandling) {}
        virtual ~DynObj() { deleteInternalObj(); }
    };
    
    /** This is the default throw on error handler */
    extern DynObj::ThrowOnError defaultThrow;
    
    /** Helper function to assert the function validity */
    inline bool assertArgsCount(Var & ret, const FuncArgs & args, const int expectedCount)
    {
        if (args.count != expectedCount)
        {
            args.errorCb(ret, Type::ErrorCallback::BadArgumentCount, Strings::FastString::Print("Expected %d arguments, got %d", expectedCount, (int)args.count));
            return false;
        }
        return true;
    }
    /** Helper function to assert the object be accessed */
    template <typename Obj>
    inline bool assertTypeCast(Var & ret, const FuncArgs & args, Obj *& thisPtr)
    {
        Type::DynObj * obj = dynamic_cast<Type::DynObj*>((Type::DynObj*)args.thisObj);
        if(!obj) { args.errorCb(ret, Type::ErrorCallback::BadThisPointer, "The given pointer to this is not pointing to a DynObj instance or RTTI is not enabled"); return false; }
        thisPtr = (Obj*)obj->getMember("$this").like((void**)0);
        if(!thisPtr) { args.errorCb(ret, Type::ErrorCallback::BadThisPointer, "The member $this is not pointing to a internal class instance"); return false; }
        return true;
    }
    
    /** Helper functions to assert the argument type validity */
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5>
    inline bool checkFuncCall(Var & ret, const FuncArgs & args, Arg1 & arg1, Arg2 & arg2, Arg3 & arg3, Arg4 & arg4, Arg5 & arg5)
    {
        if (!assertArgsCount(ret, args, 5)) return false;
        if (!args.args[0].convertInto(arg1)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 0, got '%s' - no conversion is possible", Var(arg1).getTypeName(), args.args[0].getTypeName())); return false; }
        if (!args.args[1].convertInto(arg2)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 1, got '%s' - no conversion is possible", Var(arg2).getTypeName(), args.args[1].getTypeName())); return false; }
        if (!args.args[2].convertInto(arg3)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 2, got '%s' - no conversion is possible", Var(arg3).getTypeName(), args.args[2].getTypeName())); return false; }
        if (!args.args[3].convertInto(arg4)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 3, got '%s' - no conversion is possible", Var(arg4).getTypeName(), args.args[3].getTypeName())); return false; }
        if (!args.args[4].convertInto(arg5)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 4, got '%s' - no conversion is possible", Var(arg5).getTypeName(), args.args[4].getTypeName())); return false; }
        return true;
    }
    /** Helper functions to assert the argument type validity */
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4>
    inline bool checkFuncCall(Var & ret, const FuncArgs & args, Arg1 & arg1, Arg2 & arg2, Arg3 & arg3, Arg4 & arg4)
    {
        if (!assertArgsCount(ret, args, 4)) return false;
        if (!args.args[0].convertInto(arg1)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 0, got '%s' - no conversion is possible", Var(arg1).getTypeName(), args.args[0].getTypeName())); return false; }
        if (!args.args[1].convertInto(arg2)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 1, got '%s' - no conversion is possible", Var(arg2).getTypeName(), args.args[1].getTypeName())); return false; }
        if (!args.args[2].convertInto(arg3)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 2, got '%s' - no conversion is possible", Var(arg3).getTypeName(), args.args[2].getTypeName())); return false; }
        if (!args.args[3].convertInto(arg4)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 3, got '%s' - no conversion is possible", Var(arg4).getTypeName(), args.args[3].getTypeName())); return false; }
        return true;
    }
    /** Helper functions to assert the argument type validity */
    template <typename Arg1, typename Arg2, typename Arg3>
    inline bool checkFuncCall(Var & ret, const FuncArgs & args, Arg1 & arg1, Arg2 & arg2, Arg3 & arg3)
    {
        if (!assertArgsCount(ret, args, 3)) return false;
        if (!args.args[0].convertInto(arg1)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 0, got '%s' - no conversion is possible", Var(arg1).getTypeName(), args.args[0].getTypeName())); return false; }
        if (!args.args[1].convertInto(arg2)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 1, got '%s' - no conversion is possible", Var(arg2).getTypeName(), args.args[1].getTypeName())); return false; }
        if (!args.args[2].convertInto(arg3)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 2, got '%s' - no conversion is possible", Var(arg3).getTypeName(), args.args[2].getTypeName())); return false; }
        return true;
    }
    /** Helper functions to assert the argument type validity */
    template <typename Arg1, typename Arg2>
    inline bool checkFuncCall(Var & ret, const FuncArgs & args, Arg1 & arg1, Arg2 & arg2)
    {
        if (!assertArgsCount(ret, args, 2)) return false;
        if (!args.args[0].convertInto(arg1)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 0, got '%s' - no conversion is possible", Var(arg1).getTypeName(), args.args[0].getTypeName())); return false; }
        if (!args.args[1].convertInto(arg2)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 1, got '%s' - no conversion is possible", Var(arg2).getTypeName(), args.args[1].getTypeName())); return false; }
        return true;
    }
    /** Helper functions to assert the argument type validity */
    template <typename Arg1>
    inline bool checkFuncCall(Var & ret, const FuncArgs & args, Arg1 & arg1)
    {
        if (!assertArgsCount(ret, args, 1)) return false;
        if (!args.args[0].convertInto(arg1)) { args.errorCb(ret, Type::ErrorCallback::BadArgumentType, Strings::FastString::Print("Expected '%s' for argument 0, got '%s' - no conversion is possible", Var(arg1).getTypeName(), args.args[0].getTypeName())); return false; }
        return true;
    }
    
    
    /** Make a wrapper around the given function */
    template <int line, typename Ret, Ret Func()>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret;
        if (!assertArgsCount(ret, args, 0)) return ret;
        ret = Func(); return ret;
    }
    /** Make a wrapper around the given function */
    template <int line, void Func()>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret;
        if (!assertArgsCount(ret, args, 0)) return ret;
        Func(); return ret;
    }
    // Unary
    template <int line, typename Ret, typename Arg1, Ret Func(Arg1)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg;
        if (!checkFuncCall(ret, args, arg)) return ret;
        ret = Func(arg);                    return ret;
    }
    template <int line, typename Arg1, void Func(Arg1)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg;
        if (!checkFuncCall(ret, args, arg)) return ret;
        Func(arg);                          return ret;
    }
    // Binary
    template <int line, typename Ret, typename Arg1, typename Arg2, Ret Func(Arg1, Arg2)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2;
        if (!checkFuncCall(ret, args, arg1, arg2)) return ret;
        ret = Func(arg1, arg2);                    return ret;
    }
    template <int line, typename Arg1, typename Arg2, void Func(Arg1, Arg2)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2;
        if (!checkFuncCall(ret, args, arg1, arg2)) return ret;
        Func(arg1, arg2);                          return ret;
    }
    // Ternary
    template <int line, typename Ret, typename Arg1, typename Arg2, typename Arg3, Ret Func(Arg1, Arg2, Arg3)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3)) return ret;
        ret = Func(arg1, arg2, arg3);                    return ret;
    }
    template <int line, typename Arg1, typename Arg2, typename Arg3, void Func(Arg1, Arg2, Arg3)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3)) return ret;
        Func(arg1, arg2, arg3);                          return ret;
    }
    // 4-ary
    template <int line, typename Ret, typename Arg1, typename Arg2, typename Arg3, typename Arg4, Ret Func(Arg1, Arg2, Arg3, Arg4)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4)) return ret;
        ret = Func(arg1, arg2, arg3, arg4);                    return ret;
    }
    template <int line, typename Arg1, typename Arg2, typename Arg3, typename Arg4, void Func(Arg1, Arg2, Arg3, Arg4)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4)) return ret;
        Func(arg1, arg2, arg3, arg4);                          return ret;
    }
    // 5-ary
    template <int line, typename Ret, typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, Ret Func(Arg1, Arg2, Arg3, Arg4, Arg5)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4; Arg5 arg5;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4, arg5)) return ret;
        ret = Func(arg1, arg2, arg3, arg4, arg5);                    return ret;
    }
    template <int line, typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, void Func(Arg1, Arg2, Arg3, Arg4, Arg5)>
    Var WrapFuncT(const FuncArgs & args)
    {
        Var ret; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4; Arg5 arg5;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4, arg5)) return ret;
        Func(arg1, arg2, arg3, arg4, arg5);                          return ret;
    }
    /** This is used to wrap a function call that'll do the error testing for you.
        This is very convenient as it avoid a lot of boiler plate code to ensure the given dynamic argument have the right count and type, etc...
        @param X    The return type for the function (if the function returns void, it's ommited)
        @param Y    The type of the first parameter 
        @param ...  The type of the i-th parameter, ended by the function as last parameter
        @warning If you need to declare a void returning function, don't write the return type as the first argument.
        @warning Last argument must be the function pointer */
    #define WrapFunc(X, Y, ...) &Type::WrapFuncT<__LINE__, X, Y, ## __VA_ARGS__ >
    
    /** This is used to wrap a function call that expect an object to pass in.
        The internal object pointer is saved as "$this" member and must exist during the complete lifetime of the dynamic object. */
    template <int line, class Obj, typename Ret, Ret (Obj::*Func)()>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr;
        if (!assertArgsCount(ret, args, 0)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(); return ret;
    }
    /** This is used to wrap a function call that expect an object to pass in.
        The internal object pointer is saved as "$this" member and must exist during the complete lifetime of the dynamic object. */
    template <int line, class Obj, void (Obj::*Func)()>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr;
        if (!assertArgsCount(ret, args, 0)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(); return ret;
    }
    // Unary
    template <int line, class Obj, typename Ret, typename Arg1, Ret (Obj::*Func)(Arg1)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg;
        if (!checkFuncCall(ret, args, arg)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(arg); return ret;
    }
    template <int line, class Obj, typename Arg1, void (Obj::*Func)(Arg1)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg;
        if (!checkFuncCall(ret, args, arg)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(arg); return ret;
    }
    // Binary
    template <int line, class Obj, typename Ret, typename Arg1, typename Arg2, Ret (Obj::*Func)(Arg1, Arg2)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2;
        if (!checkFuncCall(ret, args, arg1, arg2)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(arg1, arg2); return ret;
    }
    template <int line, class Obj, typename Arg1, typename Arg2, void (Obj::*Func)(Arg1, Arg2)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2;
        if (!checkFuncCall(ret, args, arg1, arg2)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(arg1, arg2); return ret;
    }
    // Ternary
    template <int line, class Obj, typename Ret, typename Arg1, typename Arg2, typename Arg3, Ret (Obj::*Func)(Arg1, Arg2, Arg3)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(arg1, arg2, arg3); return ret;
    }
    template <int line, class Obj, typename Arg1, typename Arg2, typename Arg3, void (Obj::*Func)(Arg1, Arg2, Arg3)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(arg1, arg2, arg3); return ret;
    }
    // 4-ary
    template <int line, class Obj, typename Ret, typename Arg1, typename Arg2, typename Arg3, typename Arg4, Ret (Obj::*Func)(Arg1, Arg2, Arg3, Arg4)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(arg1, arg2, arg3, arg4); return ret;
    }
    template <int line, class Obj, typename Arg1, typename Arg2, typename Arg3, typename Arg4, void (Obj::*Func)(Arg1, Arg2, Arg3, Arg4)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(arg1, arg2, arg3, arg4); return ret;
    }
    // 5-ary
    template <int line, class Obj, typename Ret, typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, Ret (Obj::*Func)(Arg1, Arg2, Arg3, Arg4, Arg5)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4; Arg5 arg5;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4, arg5)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        ret = (thisPtr->*Func)(arg1, arg2, arg3, arg4, arg5); return ret;
    }
    template <int line, class Obj, typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, void (Obj::*Func)(Arg1, Arg2, Arg3, Arg4, Arg5)>
    Var WrapObjFuncT(const FuncArgs & args)
    {
        Var ret; Obj * thisPtr; Arg1 arg1; Arg2 arg2; Arg3 arg3; Arg4 arg4; Arg5 arg5;
        if (!checkFuncCall(ret, args, arg1, arg2, arg3, arg4, arg5)) return ret;
        if (!assertTypeCast(ret, args, thisPtr)) return ret;
        (thisPtr->*Func)(arg1, arg2, arg3, arg4, arg5); return ret;
    }
    
    /** This is used to wrap a function call that'll do the error testing for you.
        This is very convenient as it avoid a lot of boiler plate code to ensure the given dynamic argument have the right count and type, etc...
        @param X    The return type for the function (if the function returns void, it's ommited)
        @param Y    The type of the first parameter 
        @param ...  The type of the i-th parameter, ended by the function as last parameter
        @warning If you need to declare a void returning function, don't write the return type as the first argument.
        @warning Last argument must be the function pointer */
    #define WrapMemberFunc(Obj, X, Y, ...) &Type::WrapObjFuncT<__LINE__, Obj, X, Y, ## __VA_ARGS__ >

    
}

#endif
